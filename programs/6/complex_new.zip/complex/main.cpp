#include <iostream>

#include <string>
#include "ComplexNumber.hpp"

int main() {
  ams562::ComplexNumber z1, z2;
  std::cout << "enter real and imag for the first complex number, separated by "
               "space: ";
  std::cin >> z1;
  std::cout << "you just entered z1 = " << z1 << '\n';
  std::string eraser;
  std::getline(std::cin, eraser);  // wipe all values in cin
  std::cout
      << "enter real and imag for the second complex number, separated by "
         "space: ";
  std::cin >> z2;
  std::cout << "you just entered z2 = " << z2 << '\n';
  // call +
  std::cout << "z1+z2 = " << z1 + z2 << '\n';
  // call -
  std::cout << "z1-z2 = " << z1 - z2 << '\n';
  // call *
  std::cout << "z1*z2 = " << z1 * z2 << '\n';
  // call  /
  std::cout << "z1/z2 = " << z1 / z2 << '\n';
  const bool equal = z1 == z2;
  const bool not_equal = z1 != z2;
  std::cout << "is z1==z2? ";
  if (equal)
    std::cout << "yes\n";
  else
    std::cout << "no\n";
  std::cout << "is z1!=z2? ";
  if (not_equal)
    std::cout << "yes\n";
  else
    std::cout << "no\n";
  return 0;
}
