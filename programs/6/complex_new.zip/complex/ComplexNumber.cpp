#include <cmath>     // sqrt
#include <iostream>  // cout

#include "ComplexNumber.hpp"

namespace ams562 {

//  default constructor
ComplexNumber::ComplexNumber() {
  _real = _imag = 0.0;  // you can do chain assignment
}

// constructor with real and imag
// NOTE default value of imag must be dropped
ComplexNumber::ComplexNumber(double real, double imag) {
  _real = real;
  _imag = imag;
}

/// helper function to do printing
void ComplexNumber::print() const {
  std::cout << '(' << _real << ',' << _imag << ")\n";
}

// return lvalue of _real
double &ComplexNumber::real() { return _real; }

// return copy of _real
double ComplexNumber::real() const { return _real; }

// return lvalue of _imag
double &ComplexNumber::imag() { return _imag; }

// return copy of imag
double ComplexNumber::imag() const { return _imag; }

// make a copy of this
ComplexNumber ComplexNumber::copy() const { return *this; }

// copy another complex number
void ComplexNumber::copy(const ComplexNumber &other) {
  _real = other._real;
  _imag = other._imag;
}

// return modulus of this
double ComplexNumber::modulus() const {
  return std::sqrt(_real * _real + _imag * _imag);
}

// return conjugate of this
ComplexNumber ComplexNumber::conj() const {
  return ComplexNumber(_real, -_imag);
}

// add this and rhs
ComplexNumber ComplexNumber::add(const ComplexNumber &rhs) const {
  return ComplexNumber(_real + rhs.real(), _imag + rhs.imag());
}

// subtract this and rhs, i.e. this-rhs
ComplexNumber ComplexNumber::sub(const ComplexNumber &rhs) const {
  return ComplexNumber(_real - rhs.real(), _imag - rhs.imag());
}

// addition and subtraction, directly calling the existing member
// functions add/sub
ComplexNumber operator+(const ComplexNumber &lhs, const ComplexNumber &rhs) {
  return lhs.add(rhs);
}
ComplexNumber operator-(const ComplexNumber &lhs, const ComplexNumber &rhs) {
  return lhs.sub(rhs);
}

// product
ComplexNumber operator*(const ComplexNumber &lhs, const ComplexNumber &rhs) {
  // compute real part
  const double real = lhs.real() * rhs.real() - lhs.imag() * rhs.imag();
  // compute imag part
  const double imag = lhs.real() * rhs.imag() + lhs.imag() * rhs.real();
  return ComplexNumber(real, imag);
}

// division, this is important
ComplexNumber operator/(const ComplexNumber &lhs, const ComplexNumber &rhs) {
  // compute lhs*conj(rhs) by calling * operator defined above
  const ComplexNumber top = lhs * rhs.conj();
  // compute bottom by calling modulus and square it
  double bot = rhs.modulus();
  // note, calling rhs.modulus() twice is expensive to do
  bot = bot * bot;
  // inverse it
  const double ibot = 1. / bot;
  return top * ibot;  // question, this is valid, but why?
}

// assignment
ComplexNumber &ComplexNumber::operator=(const ComplexNumber &rhs) {
  copy(rhs);
  return *this;  // don't forget this!
}
// plus assign
ComplexNumber &ComplexNumber::operator+=(const ComplexNumber &rhs) {
  _real += rhs._real;
  _imag += rhs._imag;
  return *this;
}
// minus assign
ComplexNumber &ComplexNumber::operator-=(const ComplexNumber &rhs) {
  _real -= rhs._real;
  _imag -= rhs._imag;
  return *this;
}

bool operator==(const ComplexNumber &lhs, const ComplexNumber &rhs) {
  return lhs.real() == rhs.real() && lhs.imag() == rhs.imag();
}
bool operator!=(const ComplexNumber &lhs, const ComplexNumber &rhs) {
  // return lhs.real() != rhs.real() || lhs.imag() != rhs.imag();
  // neat way
  return !(lhs == rhs);
}

// IO
std::ostream &operator<<(std::ostream &out, const ComplexNumber &z) {
  // format is "real imag " w/o quotations
  out << z.real() << ' ' << z.imag() << ' ';
  return out;
}
std::istream &operator>>(std::istream &in, ComplexNumber &z) {
  // load real then imag
  in >> z.real() >> z.imag();
  return in;
}

}  // namespace ams562
