#include <iostream>

#include "ComplexNumber.hpp"

int main() {
  std::cout << "create complex number (1,1)\n";
  ams562::ComplexNumber a(1, 1);
  std::cout << "assign a.real with 2 and a.imag with -1\n";
  a.real() = 2.0;
  a.imag() = -1;
  std::cout << "real=" << a.real() << '\n';
  std::cout << "imag=" << a.imag() << '\n';
  std::cout << "make a copy of a with b\n";
  ams562::ComplexNumber b;
  b.copy(a);
  std::cout << "b is ";
  b.print();
  std::cout << "mod(a) = " << a.modulus() << '\n';
  std::cout << "conj(a) is ";
  b.conj().print();
  std::cout << "create z1=(1,0) and z2=(2,-1)\n";
  ams562::ComplexNumber z1(1.0),  // what is z1.imag()?
      z2(2.0, -1.0);
  std::cout << "z1+z2 is ";
  z1.add(z2).print();
  std::cout << "z2-z1 is ";
  z2.sub(z1).print();
  return 0;
}
