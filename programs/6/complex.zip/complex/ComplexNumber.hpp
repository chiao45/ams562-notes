// AMS 562 ComplexNumber example
// author: Qiao Chen

#ifndef _COMPLEX_NUMBER
#define _COMPLEX_NUMBER

namespace ams562 {

/// \class ComplexNumber
/// \brief Simple class represented complex numbers
class ComplexNumber {
 public:
  /// default constructor
  ComplexNumber();

  /// constructor with real and imag
  /// \note This allows implicit casting
  ComplexNumber(double real, double imag = 0.0);

  /// helper function to do printing
  void print() const;

  /// return lvalue of \ref _real
  double &real();

  /// return copy of \ref _real
  double real() const;

  /// return lvalue of \ref _imag
  double &imag();

  /// return copy of imag
  double imag() const;

  /// make a copy of \a this
  ComplexNumber copy() const;

  /// copy another complex number
  /// \param[in] other another complex number
  void copy(const ComplexNumber &other);

  /// \return modulus of \a this
  double modulus() const;

  /// \return conjugate of \a this
  ComplexNumber conj() const;

  /// add this and \a rhs
  /// \param[in] rhs right-hand side complex number
  ComplexNumber add(const ComplexNumber &rhs) const;

  /// subtract this and \a rhs, i.e. this-rhs
  /// \para[in] rhs right-hand side complex number
  ComplexNumber sub(const ComplexNumber &rhs) const;

 private:
  double _real;  ///< real component
  double _imag;  ///< imaginary part
};

}  // namespace ams562

#endif
