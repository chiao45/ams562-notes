#include "include/Hello.h"
#include "include/World.h"
#include <iostream>

int main() {
    H();e();l();l();o();
    std::cout << ' ';
    W();o();r();l();d();
    std::cout << '\n';
    return 0;
}
