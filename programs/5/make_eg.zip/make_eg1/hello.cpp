#include "include/Hello.h"
#include <iostream>

int main() {
    H();e();l();l();o();
    std::cout << '\n';
}
