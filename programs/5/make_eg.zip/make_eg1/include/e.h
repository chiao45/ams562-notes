#ifndef AMS562_E_H
#define AMS562_E_H

// prototype
void e();

#endif
