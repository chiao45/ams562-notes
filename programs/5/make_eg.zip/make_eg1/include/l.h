#ifndef AMS562_L_H
#define AMS562_L_H

// prototype
void l();

#endif
