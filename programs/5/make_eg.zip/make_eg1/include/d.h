#ifndef AMS562_D_H
#define AMS562_D_H

// prototype
void d();

#endif
