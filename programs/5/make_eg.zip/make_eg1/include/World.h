#ifndef AMS562_WORLD_H
#define AMS562_WORLD_H

#include "W.h"
#include "o.h"
#include "r.h"
#include "l.h"
#include "d.h"

#endif
