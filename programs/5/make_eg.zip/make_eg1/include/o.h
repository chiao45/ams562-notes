#ifndef AMS562_O_H
#define AMS562_O_H

// prototype
void o();

#endif
