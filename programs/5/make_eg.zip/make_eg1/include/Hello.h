#ifndef AMS562_HELLO_H
#define AMS562_HELLO_H

#include "H.h"
#include "e.h"
#include "l.h"
#include "o.h"

#endif
