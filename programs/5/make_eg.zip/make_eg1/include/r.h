#ifndef AMS562_R_H
#define AMS562_R_H

// prototype
void r();

#endif
