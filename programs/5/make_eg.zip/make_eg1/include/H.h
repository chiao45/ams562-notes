#ifndef AMS562_H_H
#define AMS562_H_H

// prototype
void H();

#endif
