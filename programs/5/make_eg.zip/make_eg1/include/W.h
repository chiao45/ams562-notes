#ifndef AMS562_W_H
#define AMS562_W_H

// prototype
void W();

#endif
