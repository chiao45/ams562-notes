#include "../include/o.h"
#include <iostream>

void o() {
    std::cout << 'o';
}
