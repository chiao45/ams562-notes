#include "W.h"
#include <iostream>

void W() {
    std::cout << 'W';
}
