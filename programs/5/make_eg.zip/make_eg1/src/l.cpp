#include "../include/l.h"
#include <iostream>

void l() {
    std::cout << 'l';
}
