#include "../include/e.h"
#include <iostream>

void e() {
    std::cout << 'e';
}
