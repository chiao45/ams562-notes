#include "r.h"
#include <iostream>

void r() {
    std::cout << 'r';
}
