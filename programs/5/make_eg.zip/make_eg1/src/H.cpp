#include "../include/H.h"
#include <iostream>

void H() {
    std::cout << 'h';
}
