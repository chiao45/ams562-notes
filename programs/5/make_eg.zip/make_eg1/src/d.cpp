#include "../include/d.h"
#include <iostream>

void d() {
    std::cout << 'd';
}
