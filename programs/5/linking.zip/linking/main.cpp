
#include "hello.hpp"
#include "world.hpp"
int main() {
    hello();
    world();
    return 0;
}
