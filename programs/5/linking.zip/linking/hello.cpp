#include <iostream>
#include "hello.hpp"
void hello() {
    std::cout << "Hello ";
}
