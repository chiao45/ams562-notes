#include "world.hpp"
#include <iostream>

void world() {
    std::cout << "World\n";
}
