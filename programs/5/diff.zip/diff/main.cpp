#include <cmath>
#include <iostream>

// bring in diff
#include "diff.hpp"  // double quotation marks

int main() {
  std::cout << "sin\'(1)=" << diff(std::sin, 1) << std::endl;
  return 0;
}
