// prototype of diff
// f is input function
// x is evaluated point
// h is differential spacing
double diff(double (*f)(double), const double x, double h = 1e-5);
