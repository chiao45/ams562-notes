// first order scheme
double diff(double (*f)(double), const double x, double h) {
  if (h <= 0.0) {
    h = 1e-5;
  }
  return (f(x + h) - f(x)) / h;
}
